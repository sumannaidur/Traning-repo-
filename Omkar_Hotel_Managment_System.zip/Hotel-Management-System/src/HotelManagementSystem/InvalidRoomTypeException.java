package HotelManagementSystem;

public class InvalidRoomTypeException extends Exception {

    public InvalidRoomTypeException(String message) {
        super(message);
    }
}
