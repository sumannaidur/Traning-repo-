package TicketBooking;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Movie movie1 = new Movie(1, "Mark");
        Movie movie2 = new Movie(2, "Varanasi");
        Movie movie3 = new Movie(3, "Kantara Chapter1");

        ArrayList<Show> shows = new ArrayList<>();
        shows.add(new Show(movie1, "10:00 AM", 10));
        shows.add(new Show(movie1, "6:00 PM", 10));
        shows.add(new Show(movie2, "9:00 PM", 8));
        shows.add(new Show(movie3, "02:00 PM", 26));

        while (true) {
            ConsoleUI.clearScreen();
            ConsoleUI.header("MOVIE TICKET BOOKING SYSTEM");

            System.out.println("1. View Shows");
            System.out.println("2. Book Ticket");
            System.out.println("3. Exit");
            System.out.print("\nEnter choice: ");

            int choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    ConsoleUI.clearScreen();
                    ConsoleUI.header("AVAILABLE SHOWS");
                    for (int i = 0; i < shows.size(); i++) {
                        shows.get(i).displayShow(i + 1);
                    }
                    System.out.print("\nPress Enter...");
                    scanner.nextLine(); scanner.nextLine();
                    break;

                case 2:
                    ConsoleUI.clearScreen();
                    ConsoleUI.header("BOOK TICKET");

                    for (int i = 0; i < shows.size(); i++) {
                        shows.get(i).displayShow(i + 1);
                    }

                    System.out.print("\nSelect show number: ");
                    int showChoice = scanner.nextInt();
                    Show selectedShow = shows.get(showChoice - 1);

                    selectedShow.displaySeats();

                    System.out.print("Enter your name: ");
                    String name = scanner.next();

                    System.out.print("Enter seat number: ");
                    int seat = scanner.nextInt();

                    new BookingThread(selectedShow, seat, name).start();

                    System.out.print("\nPress Enter...");
                    scanner.nextLine(); scanner.nextLine();
                    break;

                case 3:
                    ConsoleUI.clearScreen();
                    System.out.println(ConsoleUI.YELLOW +
                            "Thank You!" +
                            ConsoleUI.RESET);
                    System.exit(0);
                    scanner.close();
            }
        }
    }
}
