package TicketBooking;
class Customer {
    protected String name;

    public Customer(String name) {
        this.name = name;
    }

    public void display() {
        System.out.println("Customer Name: " + name);
    }
}

