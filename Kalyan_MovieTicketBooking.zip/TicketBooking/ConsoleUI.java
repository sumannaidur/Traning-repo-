package TicketBooking;


public class ConsoleUI {

    public static final String RESET = "\u001B[0m";
    public static final String GREEN = "\u001B[32m";
    public static final String RED = "\u001B[31m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    public static final String CYAN = "\u001B[36m";

    public static void clearScreen() {
      
    }
    
    public static void header(String title) {
        System.out.println(RED + "====================================" + RESET);
        System.out.println(  CYAN+ "   " + title + RESET);
        System.out.println(RED + "====================================" + RESET);
    }
}
