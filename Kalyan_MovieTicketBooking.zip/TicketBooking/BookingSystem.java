package TicketBooking;

interface BookingSystem {
    void bookTicket(int seatNo);
}

