package TicketBooking;

import java.util.HashSet;
import java.util.Set;

public class Show {
    private Movie movie;
    private String time;
    private int totalSeats;
    private Set<Integer> bookedSeats = new HashSet<>();

    public Show(Movie movie, String time, int totalSeats) {
        this.movie = movie;
        this.time = time;
        this.totalSeats = totalSeats;
    }

    public synchronized boolean bookSeat(int seat) {
        if (seat < 1 || seat > totalSeats || bookedSeats.contains(seat)) {
            return false;
        }
        bookedSeats.add(seat);
        return true;
    }

    public void displayShow(int index) {
        System.out.println(index + ". " + movie.getName() + " | " + time +
                " | Available: " + (totalSeats - bookedSeats.size()));
    }

    public void displaySeats() {
        System.out.println("\nSeats Layout (X = Booked)");
        for (int i = 1; i <= totalSeats; i++) {
            if (bookedSeats.contains(i)) {
                System.out.print(ConsoleUI.RED + "[X] " + ConsoleUI.RESET);
            } else {
                System.out.print(ConsoleUI.GREEN + "[" + i + "] " + ConsoleUI.RESET);
            }
            if (i % 5 == 0) System.out.println();
        }
        System.out.println();
    }
}
