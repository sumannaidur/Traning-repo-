package TicketBooking;

public class BookingThread extends Thread {

    private Show show;
    private int seat;
    private String user;

    public BookingThread(Show show, int seat, String user) {
        this.show = show;
        this.seat = seat;
        this.user = user;
    }

    @Override
    public void run() {
        System.out.print("Processing");
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(500);
                System.out.print(".");
            }
        } catch (Exception e) {}

        System.out.println();

        if (show.bookSeat(seat)) {
            System.out.println(ConsoleUI.GREEN +
                    "✔ Seat " + seat + " booked successfully for " + user
                    + ConsoleUI.RESET);
        } else {
            System.out.println(ConsoleUI.RED +
                    "✖ Seat already booked / invalid!"
                    + ConsoleUI.RESET);
        }
    }
}
