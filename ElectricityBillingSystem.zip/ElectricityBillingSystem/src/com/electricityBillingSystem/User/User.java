package com.electricityBillingSystem.User;

	import com.electricityBillingSystem.Exception.InvalidLoginException;

	public class User {
	private String username = "chandana";
	private String password = "1234";

	public void login(String user, String pass) throws InvalidLoginException {
	if (!username.equals(user) || !password.equals(pass)) {
	throw new InvalidLoginException("Invalid Username or Password");
	}
	}
}
