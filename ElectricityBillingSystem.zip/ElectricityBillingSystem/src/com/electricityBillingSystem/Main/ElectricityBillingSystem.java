package com.electricityBillingSystem.Main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.electricityBillingSystem.Model.Customer;
import com.electricityBillingSystem.Service.BillingService;
import com.electricityBillingSystem.Service.BillingService;
import com.electricityBillingSystem.User.User;
import com.electricityBillingSystem.Exception.InvalidLoginException;

public class ElectricityBillingSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        User user = new User();
        BillingService billService = new BillingService();

        int attempts = 0;
        boolean isLoggedIn = false;

        // ---------- Login (Max 3 Attempts) ----------
        while (attempts < 3) {
            try {
                System.out.println("===== Electricity Billing System Login =====");
                System.out.print("Enter Username: ");
                String username = sc.nextLine();

                System.out.print("Enter Password: ");
                String password = sc.nextLine();

                user.login(username, password);
                isLoggedIn = true;
                System.out.println("Login Successful!\n");
                break;

            } catch (InvalidLoginException e) {
                attempts++;
                System.out.println("Login Failed: " + e.getMessage());
                System.out.println("Attempts left: " + (3 - attempts) + "\n");
            }
        }

        if (!isLoggedIn) {
            System.out.println("Maximum login attempts exceeded. Access denied.");
            sc.close();
            return;
        }

        // ---------- Billing Section ----------
        try {
            System.out.print("Enter Customer ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Customer Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Units Consumed: ");
            int units = sc.nextInt();

            if (units < 0) {
                throw new IllegalArgumentException("Units cannot be negative");
            }

            Customer customer = new Customer(id, name, units);
            double billAmount = billService.calculateBill(units);

            System.out.println("\n===== Electricity Bill =====");
            System.out.println("Customer ID   : " + customer.getCustomerId());
            System.out.println("Customer Name : " + customer.getCustomerName());
            System.out.println("Units Used    : " + customer.getUnitsConsumed());
            System.out.println("Total Bill    : Rs. " + billAmount);

        } catch (InputMismatchException e) {
            System.out.println("Invalid Input: Please enter numeric values");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
