package com.electricityBillingSystem.Model;

public class Customer {

	private int customerId;
	private String customerName;
	private int unitsConsumed;


	public Customer(int customerId, String customerName, int unitsConsumed) {
	this.customerId = customerId;
	this.customerName = customerName;
	this.unitsConsumed = unitsConsumed;
	}


	public int getCustomerId() {
	return customerId;
	}


	public String getCustomerName() {
	return customerName;
	}


	public int getUnitsConsumed() {
	return unitsConsumed;
	}
	
}
