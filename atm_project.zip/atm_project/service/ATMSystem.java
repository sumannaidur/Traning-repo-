package atm_project.service;

import atm_project.exception.InsufficientFundsException;
import atm_project.exception.InvalidCredentialsException;
import atm_project.model.Account;
import atm_project.model.SavingsAccount;
import atm_project.model.Transaction;
import atm_project.threads.CashDispenser;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ATMSystem implements ATMOperations {

    // Collection: Map to store accounts
    private static Map<String, Account> database = new HashMap<>();

    // Static block to initialize data
    static {
        database.put("123456", new SavingsAccount("123456", "1111", "Alice", 5000.00));
        database.put("654321", new SavingsAccount("654321", "2222", "Bob", 1500.00));
    }

    @Override
    public Account login(String accNum, String pin) throws InvalidCredentialsException {
        if (database.containsKey(accNum)) {
            Account user = database.get(accNum);
            if (user.validatePin(pin)) {
                return user;
            }
        }
        throw new InvalidCredentialsException("Invalid Account Number or PIN");
    }

    @Override
    public double checkBalance(Account account) {
        return account.getBalance();
    }

    @Override
    public void deposit(Account account, double amount) {
        if (amount > 0) {
            account.setBalance(account.getBalance() + amount);
            account.addTransaction(new Transaction(UUID.randomUUID().toString(), "Deposit", amount));
            System.out.println("Deposit Successful. New Balance: " + account.getBalance());
        } else {
            System.out.println("Invalid amount.");
        }
    }

    // Synchronization for Thread Safety (if multiple threads access same account)
    @Override
    public synchronized void withdraw(Account account, double amount) throws InsufficientFundsException {
        if (amount <= 0) {
            System.out.println("Invalid amount");
            return;
        }
        if (account.getBalance() >= amount) {
            // Updating balance
            account.setBalance(account.getBalance() - amount);
            account.addTransaction(new Transaction(UUID.randomUUID().toString(), "Withdrawal", amount));

            // Using Thread for dispensing cash
            Thread dispenserThread = new Thread(new CashDispenser((int) amount));
            dispenserThread.start();
            try {
                dispenserThread.join(); // Wait for hardware to finish
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("Remaining Balance: " + account.getBalance());
        } else {
            // Throwing Custom Exception
            throw new InsufficientFundsException("Insufficient funds for withdrawal.");
        }
    }

    @Override
    public void printStatement(Account account) {
        System.out.println("--- Mini Statement ---");
        System.out.println("Account: " + account.getAccountNumber());
        System.out.println("Holder: " + account.getHolderName());

        // Java 8 Streams and Lambda (optional) or foreach
        if (account.getTransactionHistory().isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            account.getTransactionHistory().forEach(t -> System.out.println(t));
        }
    }
}
