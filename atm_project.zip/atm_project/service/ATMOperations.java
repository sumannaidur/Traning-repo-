package atm_project.service;

import atm_project.exception.InsufficientFundsException;
import atm_project.exception.InvalidCredentialsException;
import atm_project.model.Account;

// Interface
public interface ATMOperations {
    Account login(String accNum, String pin) throws InvalidCredentialsException;

    double checkBalance(Account account);

    void deposit(Account account, double amount);

    void withdraw(Account account, double amount) throws InsufficientFundsException;

    void printStatement(Account account);
}
