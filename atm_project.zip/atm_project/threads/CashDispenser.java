package atm_project.threads;

public class CashDispenser implements Runnable {
    private int amount;

    public CashDispenser(int amount) {
        this.amount = amount;
    }

    @Override
    public void run() {
        System.out.println("[Hardware] Dispensing mechanism activated...");
        try {
            // Thread sleeping to simulate delay
            Thread.sleep(1000);
            System.out.println("[Hardware] Dispensing cash: " + amount);
            Thread.sleep(500);
            System.out.println("[Hardware] Please collect your cash.");
        } catch (InterruptedException e) {
            System.out.println("Dispensing interrupted.");
        }
    }
}
