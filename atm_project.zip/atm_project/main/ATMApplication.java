package atm_project.main;

import atm_project.exception.InsufficientFundsException;
import atm_project.exception.InvalidCredentialsException;
import atm_project.model.Account;
import atm_project.service.ATMOperations;
import atm_project.service.ATMSystem;

import java.util.Scanner;

public class ATMApplication {

    public static void main(String[] args) {
        ATMOperations atm = new ATMSystem();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM System");
        printLogoPattern();

        while (true) {
            try {
                System.out.println("\n--------------------------");
                System.out.print("Enter Account Number: ");
                String accNum = scanner.next();

                System.out.print("Enter PIN: ");
                String pin = scanner.next();

                // Login
                Account currentAccount = atm.login(accNum, pin);
                System.out.println("Login Successful! Welcome " + currentAccount.getHolderName());

                boolean sessionActive = true;
                while (sessionActive) {
                    System.out.println("\nSelect Operation:");
                    System.out.println("1. Check Balance");
                    System.out.println("2. Deposit");
                    System.out.println("3. Withdraw");
                    System.out.println("4. Mini Statement");
                    System.out.println("5. Logout");
                    System.out.println("6. Exit ATM");

                    int choice = scanner.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.println("Current Balance: Rs" + atm.checkBalance(currentAccount));
                            break;
                        case 2:
                            System.out.print("Enter amount to deposit: ");
                            double depAmount = scanner.nextDouble();
                            atm.deposit(currentAccount, depAmount);
                            break;
                        case 3:
                            System.out.print("Enter amount to withdraw: ");
                            double withAmount = scanner.nextDouble();
                            try {
                                atm.withdraw(currentAccount, withAmount);
                            } catch (InsufficientFundsException e) {
                                // Specific Exception Handling
                                System.err.println("Error: " + e.getMessage());
                            }
                            break;
                        case 4:
                            atm.printStatement(currentAccount);
                            break;
                        case 5:
                            sessionActive = false;
                            System.out.println("Logged out successfully.");
                            break;
                        case 6:
                            System.out.println("Thank you for banking with us.");
                            System.exit(0);
                        default:
                            System.out.println("Invalid Option");
                    }
                }

            } catch (InvalidCredentialsException e) {
                System.err.println("Login Failed: " + e.getMessage());
            } catch (Exception e) { // Generic catch
                System.err.println("An unexpected error occurred: " + e.getMessage());
                scanner.nextLine(); // Clear buffer
            }
        }
    }

    // Pattern Programming (Requirement)
    private static void printLogoPattern() {
        // Just a simple pattern
        int n = 5;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        System.out.println("   ATM   ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
