package atm_project.model;

import java.util.Date;

public class Transaction {
    private String transactionId;
    private String type; // Withdrawal, Deposit
    private double amount;
    private Date date;

    public Transaction(String transactionId, String type, double amount) {
        this.transactionId = transactionId;
        this.type = type; // String pool vs Heap is conceptual, here we just use it
        this.amount = amount;
        this.date = new Date();
    }

    @Override
    public String toString() {
        return "ID: " + transactionId + " | Type: " + type + " | Amount: " + amount + " | Date: " + date;
    }
}
