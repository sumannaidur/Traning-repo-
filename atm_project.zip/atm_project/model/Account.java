package atm_project.model;

import java.util.ArrayList;
import java.util.List;

// Abstraction
public abstract class Account {
    // Encapsulation: Private members
    private String accountNumber;
    private String pin;
    private double balance;
    private String holderName;

    // wrapper class usage (Double) usually separate, but here we use primitives
    // Collections
    private List<Transaction> transactionHistory;

    // Constrcutor
    public Account(String accountNumber, String pin, String holderName, double balance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.holderName = holderName;
        this.balance = balance;
        this.transactionHistory = new ArrayList<>();
    }

    // Abstract method (Polymorphism)
    public abstract String getAccountType();

    // Getters and Setters
    public String getAccountNumber() {
        return accountNumber;
    }

    public boolean validatePin(String inputPin) {
        // String equality check
        return this.pin.equals(inputPin);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getHolderName() {
        return holderName;
    }

    public List<Transaction> getTransactionHistory() {
        return transactionHistory;
    }

    public void addTransaction(Transaction t) {
        this.transactionHistory.add(t);
    }
}
