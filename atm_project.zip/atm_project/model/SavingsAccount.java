package atm_project.model;

// Inheritance
public class SavingsAccount extends Account {
    // Static Variable (Class variable)
    public static final double INTEREST_RATE = 3.5;

    public SavingsAccount(String accountNumber, String pin, String holderName, double balance) {
        // Super constructor
        super(accountNumber, pin, holderName, balance);
    }

    @Override
    public String getAccountType() {
        return "Savings Account";
    }
}
