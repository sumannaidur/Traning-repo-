package projectwork;

import java.util.Scanner;

public class OnlineVotingApp {

    public static void main(String[] args) {

        VotingService service = new VotingService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Online Voting System =====");
            System.out.println("1. Voter Login & Vote");
            System.out.println("2. Register New Voter");
            System.out.println("3. View Results & Percentage");
            System.out.println("4. Admin Login");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("Enter Username: ");
                    String user = sc.nextLine();

                    System.out.print("Enter Password: ");
                    String pass = sc.nextLine();

                    if (!service.login(user, pass)) {
                        System.out.println("❌ Invalid Login");
                        break;
                    }

                    if (service.hasVoted(user)) {
                        System.out.println("⚠️ You already voted!");
                        break;
                    }

                    System.out.println("\nCandidates (Sorted List):");
                    service.showResults();

                    System.out.print("\nEnter Candidate Name Exactly: ");
                    String cand = sc.nextLine();

                    if (service.vote(user, cand))
                        System.out.println("Vote recorded for " + cand);
                    else
                        System.out.println("❌ Invalid Candidate!");
                    break;

                case 2:
                    System.out.print("Enter new voter username: ");
                    String newUser = sc.nextLine();
                    System.out.print("Enter password: ");
                    String newPass = sc.nextLine();

                    if (service.registerVoter(newUser, newPass))
                        System.out.println("👍 Voter registered!");
                    else
                        System.out.println("⚠️ Username already exists!");
                    break;

                case 3:
                    service.showResults();
                    service.showPercentage();
                    break;

                case 4:
                    System.out.print("Admin Username: ");
                    String auser = sc.nextLine();
                    System.out.print("Admin Password: ");
                    String apass = sc.nextLine();

                    if (!service.adminLogin(auser, apass)) {
                        System.out.println("❌ Admin login failed!");
                        break;
                    }

                    while (true) {
                        System.out.println("\n🛂 Admin Menu:");
                        System.out.println("1. Add Candidate");
                        System.out.println("2. Reset Votes");
                        System.out.println("3. Save Results to File");
                        System.out.println("4. Declare Winner");
                        System.out.println("5. Back");
                        System.out.print("Option: ");
                        int opt = sc.nextInt();
                        sc.nextLine();

                        if (opt == 1) {
                            System.out.print("Enter new candidate name: ");
                            String cadd = sc.nextLine();
                            if (service.addCandidate(cadd))
                                System.out.println("Candidate Added!");
                            else
                                System.out.println("Already Exists!");
                        }
                        else if (opt == 2) {
                            service.resetVotes();
                            System.out.println("Votes Reset!");
                        }
                        else if (opt == 3) {
                            service.saveToFile();
                        }
                        else if (opt == 4) {
                            service.declareWinner();
                        }
                        else if (opt == 5) {
                            break;
                        }
                    }
                    break;

                case 5:
                    System.out.println("Goodbye!");
                    sc.close();
                    return;
            }
        }
    }
}
