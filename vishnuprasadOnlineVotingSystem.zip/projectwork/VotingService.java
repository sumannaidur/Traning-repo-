package projectwork;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.*;

public class VotingService {

    private HashSet<String> votedUsers = new HashSet<>();
    private TreeMap<String, Integer> votes = new TreeMap<>();
    private HashMap<String, Voter> voters = new HashMap<>();

    private final String adminUser = "admin";
    private final String adminPass = "admin123";

    public VotingService() {
        votes.put("Narendra Modi", 0);
        votes.put("Rahul Gandhi", 0);
        votes.put("Kumaraswamy", 0);

        voters.put("vishnu", new Voter("vishnu", "123"));
        voters.put("arun", new Voter("arun", "abc"));
        voters.put("kiran", new Voter("kiran", "pwd"));
    }

    public boolean login(String username, String password) {
        if (voters.containsKey(username)) {
            return voters.get(username).getPassword().equals(password);
        }
        return false;
    }

    public boolean adminLogin(String username, String password) {
        return username.equals(adminUser) && password.equals(adminPass);
    }

    public boolean hasVoted(String username) {
        return votedUsers.contains(username);
    }

    public boolean vote(String username, String candidate) {
        if (!votes.containsKey(candidate)) return false;
        votedUsers.add(username);
        votes.put(candidate, votes.get(candidate) + 1);
        return true;
    }

    public boolean registerVoter(String username, String password) {
        if (voters.containsKey(username)) return false;
        voters.put(username, new Voter(username, password));
        return true;
    }

    public boolean addCandidate(String candidate) {
        if (votes.containsKey(candidate)) return false;
        votes.put(candidate, 0);
        return true;
    }

    public void resetVotes() {
        votes.replaceAll((k, v) -> 0);
        votedUsers.clear();
    }

    public void showResults() {
        System.out.println("\n📊 Voting Results:");
        votes.forEach((k, v) -> System.out.println(k + " : " + v));
    }

    public void showPercentage() {
        int totalVotes = votes.values().stream().mapToInt(v -> v).sum();
        if (totalVotes == 0) {
            System.out.println("\nNo votes yet!");
            return;
        }

        System.out.println("\n📈 Vote Percentage:");
        votes.forEach((k, v) -> {
            double percent = (v * 100.0) / totalVotes;
            System.out.printf("%s : %.2f%% (%d votes)\n", k, percent, v);
        });
    }

    public void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("results.txt"))) {
            pw.println("Election Results:\n");
            votes.forEach((k, v) -> pw.println(k + " : " + v));
            pw.println("\nEnd of Report.");
            System.out.println("\n📁 Results saved in results.txt");
        } catch (Exception e) {
            System.out.println("Error saving file!");
        }
    }

    public void declareWinner() {
        System.out.println("\n🏆 Winner Announcement:");

        String winner = null;
        int maxVotes = -1;

        for (Map.Entry<String, Integer> entry : votes.entrySet()) {
            if (entry.getValue() > maxVotes) {
                winner = entry.getKey();
                maxVotes = entry.getValue();
            }
        }

        if (winner != null)
            System.out.println("Winner is 🎉 " + winner + " with " + maxVotes + " votes!");
        else
            System.out.println("No votes yet!");
    }
}
