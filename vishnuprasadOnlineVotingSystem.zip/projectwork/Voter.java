package projectwork;

public class Voter {
    private String username;
    private String password;

    public Voter(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}
