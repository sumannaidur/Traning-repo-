package shoppingCart;

import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {

    private Map<Product, Integer> items = new LinkedHashMap<>();

    public synchronized void addProduct(Product p) {
        items.put(p, items.getOrDefault(p, 0) + 1);
    }

    public synchronized void removeProduct(Product p) {
        if (items.containsKey(p)) {
            if (items.get(p) > 1)
                items.put(p, items.get(p) - 1);
            else
                items.remove(p);
        }
    }

    public void displayCart() {
        if (items.isEmpty()) {
            System.out.println(ConsoleUI.RED + "Cart is empty!" + ConsoleUI.RESET);
            return;
        }

        System.out.println("\n------------------------------------");
        System.out.printf("%-15s %-5s %-10s\n", "Product", "Qty", "Price");
        System.out.println("------------------------------------");

        double total = 0;
        for (Map.Entry<Product, Integer> e : items.entrySet()) {
            double price = e.getKey().getPrice() * e.getValue();
            total += price;
            System.out.printf("%-15s %-5d ₹%-10.2f\n",
                    e.getKey().getName(), e.getValue(), price);
        }

        System.out.println("------------------------------------");
        System.out.println("Total Amount: ₹" + total);
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
