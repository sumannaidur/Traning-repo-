package shoppingCart;

public class CheckoutThread extends Thread {

    @Override
    public void run() {
        System.out.print("Processing Checkout");
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(700);
                System.out.print(".");
            }
        } catch (Exception e) {}

        System.out.println();
        System.out.println(ConsoleUI.GREEN + "✔ Order Placed Successfully!" + ConsoleUI.RESET);
    }
}
