package shoppingCart;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        ArrayList<Product> products = new ArrayList<>();
        products.add(new Product(1, "Rice", 60));
        products.add(new Product(2, "Milk", 30));
        products.add(new Product(3, "Oil", 150));
        products.add(new Product(4, "Sugar", 45));

        Cart cart = new Cart();

        while (true) {

            ConsoleUI.clearScreen();
            ConsoleUI.header("SHOPPING CART SYSTEM");

            System.out.println("1. View Products");
            System.out.println("2. Add to Cart");
            System.out.println("3. Remove from Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Checkout");
            System.out.println("6. Exit");
            System.out.print("\nEnter choice: ");

            int choice = scanner.nextInt();

            switch (choice) {

                case 1:
                    ConsoleUI.clearScreen();
                    ConsoleUI.header("PRODUCT LIST");
                    for (Product p : products) {
                        System.out.println(p.getId() + ". " + p.getName() +
                                " - ₹" + p.getPrice());
                    }
                    pause(scanner);
                    break;

                case 2:
                    System.out.print("Enter product ID: ");
                    int addId = scanner.nextInt();
                    products.stream()
                            .filter(p -> p.getId() == addId)
                            .findFirst()
                            .ifPresent(cart::addProduct);
                    System.out.println(ConsoleUI.GREEN + "Added to cart!" + ConsoleUI.RESET);
                    pause(scanner);
                    break;

                case 3:
                    System.out.print("Enter product ID: ");
                    int removeId = scanner.nextInt();
                    products.stream()
                            .filter(p -> p.getId() == removeId)
                            .findFirst()
                            .ifPresent(cart::removeProduct);
                    System.out.println(ConsoleUI.YELLOW + "Removed from cart!" + ConsoleUI.RESET);
                    pause(scanner);
                    break;

                case 4:
                    ConsoleUI.clearScreen();
                    ConsoleUI.header("YOUR CART");
                    cart.displayCart();
                    pause(scanner);
                    break;

                case 5:
                    if (cart.isEmpty()) {
                        System.out.println(ConsoleUI.RED + "Cart is empty!" + ConsoleUI.RESET);
                    } else {
                        new CheckoutThread().start();
                    }
                    pause(scanner);
                    break;

                case 6:
                    ConsoleUI.clearScreen();
                    System.out.println(ConsoleUI.YELLOW + "Thank you for shopping!" + ConsoleUI.RESET);
                    System.exit(0);
            }
        }
    }

    private static void pause(Scanner sc) {
        System.out.print("\nPress Enter...");
        sc.nextLine();
        sc.nextLine();
    }
}
