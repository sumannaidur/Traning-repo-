package main;
import controller.ExamController;
public class SmartExamSystemAndCheatingDetection {
    public static void main(String[] args) {
        new ExamController().start();
    }
}
