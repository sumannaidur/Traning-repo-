package controller;
import model.*;
import view.ExamView;
import java.util.*;
public class ExamController {
    private ExamView view;
    private ArrayList<Student> students;
    private ArrayList<Question> questions;
    private Admin admin;
    public ExamController() {
        view = new ExamView();
        students = new ArrayList<>();
        questions = new ArrayList<>();
        students.add(new Student("yash", "123"));
        students.add(new Student("rahul", "111"));
        admin = new Admin("admin", "admin");
        loadQuestions();
    }
    private void loadQuestions() {
        questions.add(new Question("Which keyword is used to inherit a class in Java?",
                new String[]{"this","super","extends","implements"},3));
        questions.add(new Question("Which method is entry point of Java program?",
                new String[]{"start()","main()","run()","init()"},2));
        questions.add(new Question("Which collection does not allow duplicates?",
                new String[]{"List","ArrayList","Set","Vector"},3));
        questions.add(new Question("Which keyword is used to create object?",
                new String[]{"class","new","object","create"},2));
        questions.add(new Question("Which concept supports method overriding?",
                new String[]{"Encapsulation","Abstraction","Inheritance","Polymorphism"},4));
    }
    public void start() {
        while(true) {
            view.showMainMenu();
            int choice = view.getChoice();
            switch(choice) {
                case 1 -> studentLogin();
                case 2 -> adminLogin();
                case 3 -> { view.showMessage("Thank you"); return; }
                default -> view.showMessage("Invalid choice");
            }
        }
    }
    private void studentLogin() {
        String u = view.getUsername();
        String p = view.getPassword();
        for(Student s: students) {
            if(s.login(u,p)) {
                studentMenu(s);
                return;
            }
        }
        view.showMessage("Invalid Student Credentials");
    }
    private void studentMenu(Student s) {
        while(true) {
            view.showStudentMenu();
            int ch = view.getChoice();
            if(ch==1) conductExam(s);
            else if(ch==2) return;
            else view.showMessage("Invalid option");
        }
    }
    private void conductExam(Student s) {
        s.incrementAttempts();
        int score = 0;
        long start = System.currentTimeMillis();
        Collections.shuffle(questions);
        view.showMessage("JAVA EXAM");
        for(Question q: questions) {
            view.showMessage(q.getQuestion());
            String[] o = q.getOptions();
            for(int i=0;i<o.length;i++)
                view.showMessage((i+1)+") "+o[i]);
            int ans = view.getChoice();
            if(ans==q.getCorrectAnswer()) score++;
        }
        long time = (System.currentTimeMillis()-start)/1000;
        view.showMessage("Score: "+score+"/"+questions.size());
        view.showMessage("Time Taken: "+time+" seconds");
        if(s.getAttempts()>1) s.increaseCheatingScore();
        if(time<20) s.increaseCheatingScore();
        if(score<3) {
            s.increaseCheatingScore();
            view.showMessage("Status: FAIL");
        } else view.showMessage("Status: PASS");
    }
    private void adminLogin() {
        String u = view.getUsername();
        String p = view.getPassword();
        if(admin.login(u,p)) adminMenu();
        else view.showMessage("Invalid Admin Credentials");
    }
    private void adminMenu() {
        while(true) {
            view.showAdminMenu();
            int ch = view.getChoice();
            if(ch==1) {
                for(Student s: students)
                    view.showMessage(s.getUsername()+" | Cheating Score: "+s.getCheatingScore());
            } else if(ch==2) return;
            else view.showMessage("Invalid option");
        }
    }
}
