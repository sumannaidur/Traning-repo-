package view;
import java.util.Scanner;
public class ExamView {
    private Scanner sc = new Scanner(System.in);
    public void showMainMenu() {
        System.out.println("1. Student Login");
        System.out.println("2. Admin Login");
        System.out.println("3. Exit");
        System.out.print("Choose option: ");
    }
    public void showStudentMenu() {
        System.out.println("1. Attend Exam");
        System.out.println("2. Logout");
        System.out.print("Choose option: ");
    }
    public void showAdminMenu() {
        System.out.println("1. View Student Scores");
        System.out.println("2. Logout");
        System.out.print("Choose option: ");
    }
    public String getUsername() {
        System.out.print("Username: ");
        return sc.next();
    }
    public String getPassword() {
        System.out.print("Password: ");
        return sc.next();
    }
    public int getChoice() {
        return sc.nextInt();
    }
    public void showMessage(String msg) {
        System.out.println(msg);
    }
}
