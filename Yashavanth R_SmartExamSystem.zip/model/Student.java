package model;
public class Student extends User {
    private int cheatingScore;
    private int attempts;
    public Student(String username, String password) {
        super(username, password);
        cheatingScore = 0;
        attempts = 0;
    }
    public void increaseCheatingScore() {
        cheatingScore++;
    }
    public int getCheatingScore() {
        return cheatingScore;
    }
    public void incrementAttempts() {
        attempts++;
    }
    public int getAttempts() {
        return attempts;
    }
}
